export default function Accueil() {
  return (
    <div>
      <h1>Bienvenue sur l'application de gestion des tâches</h1>
      <p>
        Cette application vous permet de gérer vos tâches en les ajoutant, en les marquant comme faites et en les supprimant.
      </p>
      <p>Pour commencer, rendez-vous sur la page "Tâches".</p>
    </div>
  );
}
