export default function Apropos() {
  return (
    <div>
      <h1>À propos</h1>
      <p>Cette application a été créée dans le cadre du cours React.</p>
    </div>
  );
}