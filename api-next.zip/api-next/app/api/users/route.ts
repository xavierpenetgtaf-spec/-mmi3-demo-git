const users = [
  { id: 1, name: 'xavier Penet Gillig' },
  { id: 2, name: 'Benois Saint Denis' },
  { id: 3, name: 'Fares Ziam' },
];

export async function GET() {
  return Response.json({ users: users });
}