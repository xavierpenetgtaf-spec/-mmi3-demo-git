module.exports = [
"[project]/.next-internal/server/app/apropos/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_apropos_page_actions_e94986ae.js.map