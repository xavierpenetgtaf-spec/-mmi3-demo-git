var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/users/route.js")
R.c("server/chunks/node_modules_next_dist_5378ef35._.js")
R.c("server/chunks/[root-of-the-server]__c640dc61._.js")
R.c("server/chunks/_next-internal_server_app_api_users_route_actions_4b9121e3.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/users/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/users/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
